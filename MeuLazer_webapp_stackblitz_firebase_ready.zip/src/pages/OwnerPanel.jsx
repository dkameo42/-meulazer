import React, { useEffect, useState } from "react";
import { auth } from "../firebase";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { useNavigate } from "react-router-dom";

export default function OwnerPanel() {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      if (u) {
        setUser(u);
      } else {
        navigate("/login");
      }
    });
    return () => unsub();
  }, [navigate]);

  const handleLogout = async () => {
    await signOut(auth);
    navigate("/login");
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-lg p-6">
        <h1 className="text-2xl font-semibold mb-2">Owner Panel</h1>
        <p className="text-sm text-gray-600 mb-4">Bem-vindo, {user.displayName || "(sem nome)"}</p>
        <div className="bg-gray-50 p-4 rounded mb-4">
          <div className="text-sm text-gray-700"><strong>E-mail:</strong> {user.email}</div>
          <div className="text-sm text-gray-700"><strong>UID:</strong> {user.uid}</div>
        </div>
        <button
          onClick={handleLogout}
          className="px-4 py-2 bg-red-500 text-white rounded-xl"
        >
          Sair
        </button>
      </div>
    </div>
  );
}