# MeuLazer - Web App Starter (PWA)

Scaffold inicial para o MeuLazer — PWA em React/Vite com instruções para integrar Firebase e gateway de pagamentos.
