import React from 'react'
import { useParams, Link } from 'react-router-dom'

export default function Details(){
  const { id } = useParams()
  const space = {id, title:'Chácara Sol Nascente', neighborhood:'Centro', price:350, description:'Espaço com piscina, churrasqueira e área coberta.', lat:-21.5, lng:-48.6}
  return (
    <div>
      <div className='header'><h3>MeuLazer</h3><Link to='/login'>Entrar</Link></div>
      <div className='container'>
        <div className='card'>
          <h2>{space.title}</h2>
          <p className='small'>{space.neighborhood} • R$ {space.price}</p>
          <p>{space.description}</p>
          <div style={{display:'flex',gap:8,marginTop:12}}>
            <a className='btn' href={`https://www.google.com/maps/dir/?api=1&destination=${space.lat},${space.lng}`} target='_blank' rel='noreferrer'>📍 Ver rota</a>
            <Link to={'/book/'+space.id}><button className='btn'>Reservar</button></Link>
          </div>
        </div>
      </div>
    </div>
  )
}