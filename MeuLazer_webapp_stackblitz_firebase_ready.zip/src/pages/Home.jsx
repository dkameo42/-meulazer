import React from 'react'
import { Link } from 'react-router-dom'

const sampleSpaces = [
  {id:'1', title:'Chácara Sol Nascente', neighborhood:'Centro', price:350, amenities:['Piscina','Churrasqueira']},
  {id:'2', title:'Espaço Rio Verde', neighborhood:'Jardim', price:280, amenities:['Piscina','Quadra']},
]

export default function Home(){
  return (
    <div>
      <div className='header'><h3>MeuLazer</h3><Link to='/login'>Entrar</Link></div>
      <div className='container'>
        <div style={{display:'flex',gap:12,margin:'12px 0'}}>
          <input placeholder='Buscar por bairro' style={{flex:1,padding:10,borderRadius:8,border:'1px solid #ddd'}}/>
          <button className='btn'>Buscar</button>
        </div>
        <h4>Espaços disponíveis</h4>
        {sampleSpaces.map(s => (
          <div className='card' key={s.id}>
            <h3>{s.title}</h3>
            <p className='small'>{s.neighborhood} • R$ {s.price}</p>
            <p>{s.amenities.join(' • ')}</p>
            <div style={{display:'flex',gap:8,marginTop:8}}>
              <Link to={'/details/'+s.id}><button className='btn'>Ver</button></Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}