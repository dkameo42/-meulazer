import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { auth } from "../firebase";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup,
} from "firebase/auth";

export default function Login() {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const provider = new GoogleAuthProvider();

  const handleGoogle = async () => {
    setError(null);
    setLoading(true);
    try {
      await signInWithPopup(auth, provider);
      navigate("/owner");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleEmail = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      if (isRegister) {
        await createUserWithEmailAndPassword(auth, email, password);
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      navigate("/owner");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-slate-50 to-white">
      <div className="w-full max-w-md p-6 bg-white rounded-2xl shadow-lg">
        <h2 className="text-2xl font-semibold text-center mb-4">MeuLazer</h2>

        <button
          onClick={handleGoogle}
          className="w-full mb-4 px-4 py-2 rounded-xl border border-gray-200 hover:shadow"
          disabled={loading}
        >
          Entrar com Google
        </button>

        <div className="text-center text-sm text-gray-500 mb-4">ou</div>

        <form onSubmit={handleEmail} className="space-y-3">
          <input
            className="w-full px-4 py-2 border rounded-xl focus:outline-none focus:ring"
            placeholder="E-mail"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            required
          />
          <input
            className="w-full px-4 py-2 border rounded-xl focus:outline-none focus:ring"
            placeholder="Senha"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            type="password"
            required
            minLength={6}
          />
          {error && (
            <div className="text-sm text-red-600 bg-red-50 p-2 rounded">{error}</div>
          )}
          <button
            className="w-full bg-blue-600 text-white py-2 rounded-xl disabled:opacity-60"
            type="submit"
            disabled={loading}
          >
            {isRegister ? "Criar conta" : "Entrar"}
          </button>
        </form>

        <div className="mt-4 text-center">
          <button
            className="text-sm text-slate-600 underline"
            onClick={() => setIsRegister(!isRegister)}
          >
            {isRegister ? "Já tem conta? Entrar" : "Criar conta com e-mail"}
          </button>
        </div>
      </div>
    </div>
  );
}