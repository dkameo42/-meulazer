import React, { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import QRCode from 'qrcode.react'

export default function Book(){
  const { id } = useParams()
  const [method, setMethod] = useState('pix')
  const [showQR, setShowQR] = useState(false)
  const pixCode = '00020126580014BR.GOV.BCB.PIX0114+552199999999520400005303986540530.005802BR5925MeuLazer Chacara6009SAO PAULO62070503***63041D3D' // mock

  const handlePay = () => {
    if(method === 'pix'){
      setShowQR(true)
    } else {
      alert('Chamando gateway de cartão (placeholder)')
    }
  }

  return (
    <div>
      <div className='header'><h3>MeuLazer</h3><Link to='/'>Voltar</Link></div>
      <div className='container'>
        <div className='card'>
          <h3>Finalizar reserva</h3>
          <p className='small'>Valor total: R$ 350</p>
          <div style={{display:'flex',gap:8,marginTop:8}}>
            <label><input type='radio' checked={method==='pix'} onChange={()=>setMethod('pix')} /> Pix</label>
            <label><input type='radio' checked={method==='card'} onChange={()=>setMethod('card')} /> Cartão (crédito/débito)</label>
          </div>
          <div style={{marginTop:12}}>
            <button className='btn' onClick={handlePay}>Confirmar pagamento</button>
          </div>
          {showQR && (
            <div style={{marginTop:20,textAlign:'center'}} className='card'>
              <p>Escaneie o QR Code com seu app do banco ou copie o código Pix</p>
              <QRCode value={pixCode} size={180} />
              <pre style={{wordBreak:'break-all',fontSize:12,marginTop:8}}>{pixCode}</pre>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}